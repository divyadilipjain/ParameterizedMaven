package lib.cisco.util;

import java.io.FileInputStream;

import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.util.PDFTextStripper;

public class PDFValidation {
	public boolean validatePDF(String key,String PDFPath)
	{
		boolean flag=false;
		try {
			FileInputStream pdf = new FileInputStream(PDFPath);
					
			PDFParser parser = new PDFParser(pdf);
			parser.parse();
			String text = new PDFTextStripper().getText(parser.getPDDocument());
			//System.out.println(text);
			if (text.contains(key)) {
				flag=true;
				System.out.println(key + " is available in "+PDFPath);
			}
			else
			{
				flag=false;
				System.out.println(key + " is not available in "+PDFPath);
				
			}
			parser.getPDDocument().close();
			pdf.close();
		}

		catch (Exception e) {

			flag=false;
			System.out.println("Exception in PDF Search");
		}
		return flag;
	}
		

	
	
			
}
