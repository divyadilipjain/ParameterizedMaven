package lib.cisco.util;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import java.io.FileInputStream;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

public class WordFileValidation {

	public boolean wordValidation(String key, String docPath) {
		System.out.println("Into Word Validation Function!!");
		System.out.println("Doc Path:"+docPath+",key:"+key);
		boolean flag = false;
		try {

			FileInputStream fis = new FileInputStream(docPath);
			XWPFWordExtractor textExtractor = new XWPFWordExtractor(new XWPFDocument(fis));
			String wordText = textExtractor.getText();
			
			if (wordText.contains(key)) {

				flag = true;
				System.out.println(key + " is available in " + docPath);

			} else {

				flag = false;
				System.out.println(key + " is not available in " + docPath);

			}
		} catch (Exception e) {

			flag = false;
			
			System.out.println("Exception in Word Search");

		}
		return flag;

	}
	public static void main(String args[])
	{
		WordFileValidation wf=new WordFileValidation();
		wf.wordValidation("configuration", "C:\\Users\\divyjain\\Desktop\\ATOM DOCS\\Mavenizing OATS.docx");
		System.out.println("Complete");
	}
}
	
	

	